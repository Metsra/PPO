document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const nome = document.getElementById('nome').value.trim();
      const mensagem = document.getElementById('mensagem').value.trim();
      if (!nome || !mensagem) {
        alert('Por favor, preencha todos os campos.');
        return;
      }
      alert(`Mensagem enviada com sucesso!\nObrigado por entrar em contato, ${nome}!`);
      form.reset();
    });
  }
});